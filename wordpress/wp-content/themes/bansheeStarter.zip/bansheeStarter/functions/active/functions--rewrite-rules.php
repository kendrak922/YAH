<?php
// function rewrite_rules() {
//     add_rewrite_rule( 'resource/page/?([0-9]{1,})/?$', 'index.php?post_type=resource&paged=$matches[1]', 'top' );
//     add_rewrite_rule( 'resource/(.+)/page/?([0-9]{1,})/?$', 'index.php?resource_type=$matches[2]&paged=$matches[3]', 'top' );
// }
?>