<?php

use Lean\Load;

$form = $args['form'];
if (!$form) {
    //exit molecule
    return;
}
?>

<div data-molecule="form">

</div>